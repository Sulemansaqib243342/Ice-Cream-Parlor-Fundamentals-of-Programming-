#include <iostream>
#include <fstream>
using namespace std;

struct IceCream {
    string flavor;
    float price;
};

// ================= MENUS =================

void displayMainMenu() {
    cout << "\n=========================================\n";
    cout << "        WELCOME TO ICE CREAM SHOP\n";
    cout << "=========================================\n";
    cout << " 1. Add Ice Cream\n";
    cout << " 2. Delete Ice Cream\n";
    cout << " 3. View Receipt\n";
    cout << " 4. Save Receipt\n";
    cout << " 0. Exit\n";
    cout << "=========================================\n";
    cout << "Enter your choice: ";
}

void displayIceCreamMenu() {
    cout << "\n=========================================\n";
    cout << "        ICE CREAM PARLOR MENU\n";
    cout << "=========================================\n";
    cout << " No   Flavor              Price (Rs.)\n";
    cout << "-----------------------------------------\n";
    cout << " 1    Vanilla             50\n";
    cout << " 2    Chocolate           100\n";
    cout << " 3    Strawberry          125\n";
    cout << " 4    Mango               150\n";
    cout << " 5    ButterScotch        175\n";
    cout << "-----------------------------------------\n";
    cout << " 0    Finish Ordering\n";
    cout << "=========================================\n";
    cout << "Enter your choice: ";
}

void displayToppingsMenu() {
    cout << "\n=========================================\n";
    cout << "            TOPPINGS MENU\n";
    cout << "=========================================\n";
    cout << " No   Topping             Price (Rs.)\n";
    cout << "-----------------------------------------\n";
    cout << " 1    Sprinkles           20\n";
    cout << " 2    Chocolate Chips     30\n";
    cout << " 3    Chocolate Syrup     40\n";
    cout << " 4    Oreo                50\n";
    cout << "-----------------------------------------\n";
    cout << " 0    No More Toppings\n";
    cout << "=========================================\n";
    cout << "Enter topping choice: ";
}

// ================= RECEIPT =================

void printReceipt(IceCream order[], int count, float total) {
    if (count == 0) {
        cout << "\nNo items in order.\n";
        return;
    }

    cout << "\n=========================================\n";
    cout << "               RECEIPT\n";
    cout << "=========================================\n";
    cout << " No   Item               Price (Rs.)\n";
    cout << "-----------------------------------------\n";

    for (int i = 0; i < count; i++) {
        cout << " " << i + 1 << "    " << order[i].flavor;

        int spaces = 20 - order[i].flavor.length();
        for (int j = 0; j < spaces; j++) cout << " ";

        cout << order[i].price << endl;
    }

    cout << "-----------------------------------------\n";
    cout << " TOTAL AMOUNT:          Rs. " << total << endl;
    cout << "=========================================\n";
}

// ================= FILE SAVE =================

void saveReceipt(IceCream order[], int count, float total) {
    ofstream file("receipt.txt");

    if (!file) {
        cout << "Error saving file.\n";
        return;
    }

    file << "========== RECEIPT ==========\n";
    for (int i = 0; i < count; i++) {
        file << i + 1 << ". " << order[i].flavor
             << " - Rs. " << order[i].price << endl;
    }
    file << "Total: Rs. " << total << endl;

    file.close();
    cout << "Receipt saved to receipt.txt\n";
}

// ================= ADD ICE CREAM =================

void addIceCream(IceCream order[], int &count, float &total) {

    IceCream menu[5] = {
        {"Vanilla", 50},
        {"Chocolate", 100},
        {"Strawberry", 125},
        {"Mango", 150},
        {"ButterScotch", 175}
    };

    float toppingPrice[4] = {20, 30, 40, 50};

    int choice, tChoice;

    displayIceCreamMenu();
    cin >> choice;

    if (choice >= 1 && choice <= 5) {
        order[count] = menu[choice - 1];
        total += menu[choice - 1].price;
        count++;

        cout << "Ice cream added successfully!\n";

        // toppings loop
        do {
            displayToppingsMenu();
            cin >> tChoice;

            if (tChoice >= 1 && tChoice <= 4) {
                total += toppingPrice[tChoice - 1];
                cout << "Topping added!\n";
            }
            else if (tChoice != 0) {
                cout << "Invalid choice!\n";
            }

        } while (tChoice != 0);
    }
    else if (choice != 0) {
        cout << "Invalid choice!\n";
    }
}

// ================= DELETE =================

void deleteIceCream(IceCream order[], int &count, float &total) {
    if (count == 0) {
        cout << "No items to delete.\n";
        return;
    }

    printReceipt(order, count, total);

    int index;
    cout << "Enter item number to delete: ";
    cin >> index;

    if (index >= 1 && index <= count) {
        total -= order[index - 1].price;

        for (int i = index - 1; i < count - 1; i++) {
            order[i] = order[i + 1];
        }

        count--;
        cout << "Item deleted successfully!\n";
    }
    else {
        cout << "Invalid choice!\n";
    }
}

// ================= MAIN =================

int main() {
    IceCream order[100];
    int count = 0;
    float total = 0;

    int choice;

    do {
        displayMainMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            addIceCream(order, count, total);
            break;
        case 2:
            deleteIceCream(order, count, total);
            break;
        case 3:
            printReceipt(order, count, total);
            break;
        case 4:
            saveReceipt(order, count, total);
            break;
        case 0:
            cout << "Thank you for visiting!\n";
            break;
        default:
            cout << "Invalid choice!\n";
        }

    } while (choice != 0);

    return 0;
}